#higher lower game
#art.py contains logo and vs logo
# game_data contains the list of dictionary entries: name, follower_count, description (job), country
import random #import random to randomly select from the list in dictionary
from game_data import data #import game data
from art import logo, vs
from replit import clear

#Print logo
print(logo)
score = 0
should_continue = True
#generate a random account from the game_data file
def get_player():
  return random.choice(data)
contestant_B = get_player()

#function to format the data, omitting the follower count
def format_data(account):
  """Takes account data that we have and returns a printable format."""
  account_name = account["name"]
  account_desc = account["description"]
  account_country = account["country"]
  return f"{account_name}, a {account_desc}, from {account_country}"

#check the answers generated 
def check_answer(guess, a_followers, b_followers):
  """Take the user guess and follower counts and return if they got it right."""
  if a_followers > b_followers:
    return guess == "A"
  else: #if b has more followers; if guess is also b
    return guess == "B"


#loops the game
while should_continue == True:  
  #sets the contestant A = to old contestant B
  contestant_A = contestant_B
  contestant_B = get_player()
  #enforces removal of duplicates
  while contestant_A == contestant_B:
    contestant_B = get_player()
    

  print(f"Compare A: {format_data(contestant_A)}.")
  #versus logo
  print(vs)
  #"Against B: {name}, {description}, from {country}"
  print(f"Against B: {format_data(contestant_B)}.")
  #"Who has more followers? Type 'A' or 'B': "
  guess = input("Who has more followers? Type 'A' or 'B':  ").upper() 

  #check follower counts
  A_follower_count = contestant_A["follower_count"]
  B_follower_count = contestant_B["follower_count"]
  is_correct = check_answer(guess, A_follower_count, B_follower_count)

  #clear the table between screens; ensure logo is still in same spot each iteration
  clear()
  print(logo)
  #if correct, switch the winner to slot A and generate random for B
  if is_correct:
    score +=1
    print(f"You're right! Current score: {score}")
  #if incorrect: "Sorry, that's wrong. Final score: {score}"
  else:
    print(f"Sorry, that's wrong. Final score: {score}.")
    should_continue = False
