from replit import clear
from art import logo
#HINT: You can call clear() to clear the output in the console.
print(logo)

bids = {}
bidding_finished = False
max_bidder = {}

def find_highest_bidder(bidding_record):
  highest_bid = 0
  winner = ""
  # bidding record is comprised of key:value pairs {"Angela" : 200, "Tom": 100, "Steven" : 50}
  for bidder in bidding_record: #this loops through each of the keys,
    bid_amount = bidding_record[bidder]
    if bid_amount > highest_bid:
      highest_bid = bid_amount
      winner = bidder
  print(f"The winner is {winner}, with a bid of ${highest_bid}!")


while not bidding_finished:
  name = input("What is your name?: ")
  price = int(input("What is your bid?: $"))
  # adds the bidder dictionary to the bids dictionary above
  bids[name] = price
  # clears and loops if there are more bidders to come
  should_continue = input("Are there any other bidders? Type 'yes' or 'no'.\n").lower()
  if should_continue == "no":
    bidding_finished = True
    clear()
  elif should_continue =="yes":
    clear()
  find_highest_bidder(bids)
