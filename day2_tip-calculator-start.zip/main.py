#If the bill was $150.00, split between 5 people, with 12% tip. 
#Each person should pay (150.00 / 5) * 1.12 = 33.6
#Format the result to 2 decimal places = 33.60
#Tip: There are 2 ways to round a number. You might have to do some Googling to solve this.💪
#Write your code below this line 👇
#ask the questions to gather input
print("Welcome to the Tip Calculator!")
bill = float(input("What was the total bill?\n"))
tip_pct = int(input("what percentage tip would you like to give? 12, 15, or 20?\n"))
split = int(input("How many people to split the bill?\n"))

#calculate the tip amount
total_with_tip = bill * (1 + (tip_pct/100))
split_with_tip = total_with_tip / split

#round the split amount to 2 decimal places 
final_amount = round(split_with_tip, 2)
final_amount = "{:.2f}".format(split_with_tip)

#print the result
print(f"Each person should pay: ${final_amount}.")